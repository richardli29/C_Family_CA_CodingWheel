#include <util_node.h>

/*function definitions*/
void display(int argc, char **argv){
  /*List parameters from the inputs of argv*/
  printf("Parameter Listing\n");
  int i;
  for (i = 1; i<argc; i++){
    printf("\t%d:%s\n",i,argv[i]);
  }
  /*checking enough parameters*/
  if (argc<5){
    printf ("Not enough arguments entered .\n ");
    exit (1);
  }
}
/*create doubly linked list*/
void startList(struct Node** root, char wheelValues[]){
  int i;

  for(i =0; i<strlen(wheelValues);i++){
    if(*root == NULL){
	/*for first element in the linked list*/
    struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));
    new_node -> data = wheelValues[i];
    new_node -> next = new_node -> prev = new_node;
    *root = new_node;
    }
    else{
	/* link the last node to the first node to make it circular*/
    struct Node* end = (struct Node*)malloc(sizeof(struct Node));
    end = (*root) -> prev;

    struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));
    new_node -> data = wheelValues[i];

    (*root) -> prev = new_node;

    new_node -> prev = end;
    new_node -> next = (*root);

    end -> next = new_node;
    }
  }
}

void chars(char **str ,char inputFile[]){
/*get input file - coding wheel and prints values, handling blank spaces and any repeating characters*/
  FILE * fp;
  char ch;
  int count = 0;
  int size;
  char prev;
  fp = fopen(inputFile, "r");
  if (fp==NULL){
      printf("Unable to open file for read access.\n ");
      exit(1);
  }
  while((ch = fgetc(fp)) != EOF){
    if(ch == '\n')
      size++;
  }
  rewind(fp);

  if(!(*str = (char *)malloc(sizeof(char)*size))){
    printf("Out of memory\n");
    exit(1);
  }
  /*deal with blank and repeating characters*/
  while((ch = fgetc(fp)) != EOF){
    if (ch != '\n')
      str[0][count++] = ch;

    if (ch == '\n' && prev == '\n')
      str[0][count++] = ' ';

    prev = ch;
  }
  str[0][count]='\0';
  fclose(fp);
}


void encode(struct Node* root, char str[], int **coded, int lenWheel){
  struct Node *current = root;
  int i;
	/*deal with memory leaks*/
  if (!(*coded = (int *)malloc(sizeof(int)*strlen(str)))){
    printf("Out of memory");
    exit(1);
  }
  for(i = 0; i<strlen(str); i++){
    int count = 0;
    
    while (count < lenWheel){
      if(current -> data == str[i])
        break;

      else{
      current = current -> next;
      count++;
      }
    }
    if(count>((lenWheel/2)))
      count = count - lenWheel;

    coded[0][i] = count;
    
  }
}

void decode(struct Node* root, int numbers[], char **decoded, int len){
  struct Node *current = root;
  int i;

  if (!(*decoded = (char *)malloc(sizeof(char)*len))){
    printf("Out of memory");
    exit(1);
  }
  for(i = 0; i<len; i++){
    int count = numbers[i];
    while(count != 0){
      if (count<0){
        current = current -> prev;
        count++;
      }
      else{
        current = current -> next;
        count--;
      }
    }
    decoded[0][i] = current -> data;
  }
}
