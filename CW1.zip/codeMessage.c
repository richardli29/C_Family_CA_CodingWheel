#include <util_node.h>

int main(int argc, char **argv){
  display(argc, argv);
  /*getting wheel characters from wheel file*/
  char *inputFile = argv[1];
  char *wheel;

  chars(&wheel, inputFile);
  printf("Coding Wheel values:\n\t %s\n",wheel);

  /*create doubly linked list*/
  struct Node* root = NULL;
  startList(&root, wheel);

  int lenWheel;
  lenWheel = strlen(wheel);

  /*free wheel to avoid memory leakage*/
  free(wheel);

  /*check if being coded or decoded*/
  if (strcmp(argv[3],"C")==0){
    /*string to be coded*/
    int *coded;
    int i;
    char input[] = " ";
    char buffer[12]="aaaa";
    encode(root, argv[4], &coded, lenWheel);

    for(i = 0; i<strlen(argv[4]);i++){
      sprintf(buffer,"%d",coded[i]);
      printf("%d\n",coded[i]);
      strcat(input, buffer);
      strcat(input, " ");
      printf("%s\n",input);
    }
    int size = strlen(input);

    FILE *file = fopen(argv[2], "w");
    fwrite(input, sizeof(char), size, file);
    fclose(file);
  }

  if (strcmp(argv[3],"D")==0){
    /*numbers from argv[4]+ to be decoded*/
    char *decoded;
    int i;

    int size = argc - 4 ;
    int* nums  = (int*)calloc(size, sizeof(int));

    for(i = 0; i < size; i++){
      sscanf(argv[i + 4], "%d", &nums[i]);
    }
    decode(root, nums, &decoded, size);

    FILE *file = fopen(argv[2], "w");
    fwrite(decoded, sizeof(char), sizeof(decoded), file);
    fclose(file);

    free(decoded);
  }

  /*store in file given in argv[2]*/
  return 0;
}