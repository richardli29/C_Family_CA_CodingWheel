#!/bin/bash

gcc -ansi -I./ -c codeMessage.c -o codeMessage.o
gcc -ansi -I./ -c util_coding.c -o util_coding.o

gcc codeMessage.o util_coding.o -o codeMessage