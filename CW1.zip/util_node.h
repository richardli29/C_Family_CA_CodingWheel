#indef UTIL_NODE_H
#define UTIL_NODE_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* structure definition*/
struct Node{
char data;
struct Node *next;
struct Node *prev;
};

/*function prototypes*/
void display(int argc, char **argv);
void startList(struct Node ** root, char wheelValues[]);
void chars(char **s, char inputFile[]);
void encode(struct Node* root, char letters[], int **coded, int lenWheel);
void decode(struct Node* root, int numbers[], char **decoded, int len);